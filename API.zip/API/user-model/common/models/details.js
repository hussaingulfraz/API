'use strict';

module.exports = function(Details) {

};
